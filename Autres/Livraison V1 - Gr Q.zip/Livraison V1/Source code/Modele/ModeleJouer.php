<?php
	include_once("Jouer.php");
	include_once("../include/connect.inc.php");

	class ModeleJouer {
		
	}
?>
