

<!-- Main jumbotron for a primary marketing message or call to action -->
    <div class="jumbotron">
      <div class="container">
      </br></br>
        <h1>Choix des mondes</h1>     
      </div>
    </div>
    <div class="container">
      &nbsp &nbsp &nbsp &nbsp  &nbsp &nbsp &nbsp &nbsp<a type="button" href="./index.php?entite=parcours1" class="btn btn-primary btn-lg"><div ><h1 class ='mafonte2'> Les Secondes</h1></div></a> &nbsp
      <a type="button" href="Vue/Parcours.php" class="btn btn-success btn-lg"> <div class ='mafonte2'><h1> Les Premières </h1></div></a> &nbsp
     <a type="button" href="Vue/Parcours.php" class="btn btn-danger btn-lg"><div class ='mafonte2'><h1> Les Terminales </h1></div></a> 
      

